﻿namespace MusicAPI2.Models.Repositories
{
    public static class SongRepo
    {
        private static List<Song> songs = new List<Song>()
        {
            new Song{ SongId = 1, SongName = "Song_1", Artist = "Artist_1", Genre = "Pop", Album = "A1_Album_1", Year = 2000, Price = 1.99},
            new Song{ SongId = 2, SongName = "Song_2", Artist = "Aritst_2", Genre = "Rnb", Album = "A2_Album_1", Year = 1993, Price = 1.50},
            new Song{ SongId = 3, SongName = "Song_3", Artist = "Artist_3", Genre = "Rap", Album = "A3_Album_1", Year = 2005, Price = 1.89},
            new Song{ SongId = 4, SongName = "Song_4", Artist = "Artist_2", Genre = "Rnb", Album = "A2_Album_2", Year = 1998, Price = 1.99},
        };

        public static List<Song> GetSongs() 
        { 
            return songs; 
        }

        public static bool SongExsists(int id)
        {
            return songs.Any(x => x.SongId == id);
        }

        public static Song? GetSongById(int id)
        { 
            return songs.FirstOrDefault(x => x.SongId == id); 
        }

        public static Song? GetSongByProperties(string? songName, string? artist, string? album, int? year)
        {
            return songs.FirstOrDefault(x =>
                !string.IsNullOrWhiteSpace(songName) &&
                !string.IsNullOrWhiteSpace(x.SongName) &&
                x.SongName.Equals(songName, StringComparison.OrdinalIgnoreCase) &&
                !string.IsNullOrWhiteSpace(artist) &&
                !string.IsNullOrWhiteSpace(x.Artist) &&
                x.Artist.Equals(artist, StringComparison.OrdinalIgnoreCase) &&
                !string.IsNullOrWhiteSpace(album) &&
                !string.IsNullOrWhiteSpace(x.Album) &&
                x.Album.Equals(album, StringComparison.OrdinalIgnoreCase) &&
                year.HasValue &&
                x.Year.HasValue &&
                year.Value == x.Year.Value);
        }

        public static void AddSong(Song song)
        {
            int maxId = songs.Max(x => x.SongId);
            song.SongId = maxId + 1;

            songs.Add(song);
        }

        public static void UpdateSong(Song song)
        {
            var songToUpdate = songs.First(x => x.SongId == song.SongId);
            songToUpdate.SongName = song.SongName;
            songToUpdate.Artist = song.Artist;
            songToUpdate.Album = song.Album;
            songToUpdate.Year = song.Year;
            songToUpdate.Genre = song.Genre;
            songToUpdate.Price = song.Price;
        }

        public static void DeleteSong(int songId)
        {
            var song = GetSongById(songId);
            if (song != null)
            {
                songs.Remove(song);
            }
        }

    }
}
