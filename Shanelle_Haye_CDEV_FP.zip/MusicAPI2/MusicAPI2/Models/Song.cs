﻿using System.ComponentModel.DataAnnotations;

namespace MusicAPI2.Models
{
    public class Song
    {
        public int SongId { get; set; }

        [Required]
        public string? SongName { get; set;}

        [Required]
        public string? Artist { get; set;}


        public string? Genre { get; set;}
        public string? Album { get; set;}

        [Required]
        public int? Year { get; set; }
        public double? Price { get; set; }
    }
}
