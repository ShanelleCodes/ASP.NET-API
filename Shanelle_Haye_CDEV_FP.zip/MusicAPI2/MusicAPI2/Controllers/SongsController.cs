﻿using Microsoft.AspNetCore.Mvc;
using MusicAPI2.Filters;
using MusicAPI2.Filters.ActionFilters;
using MusicAPI2.Filters.ExceptionFilters;
using MusicAPI2.Models;
using MusicAPI2.Models.Repositories;
using System.Diagnostics.Contracts;

namespace MusicAPI2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SongsController: ControllerBase
    {
        
        [HttpGet]
        public IActionResult GetSongs()
        {
            return Ok(SongRepo.GetSongs());
        }

        [HttpGet("{id}")]
        [Song_ValidateSongIdFilter]
        public IActionResult GetSongById(int id)
        {
            return Ok(SongRepo.GetSongById(id));
        }

        [HttpPost]
        [Song_ValidateCreateSongFilter]
        public IActionResult CreateSong([FromBody] Song song)
        {
            SongRepo.AddSong(song);

            return CreatedAtAction(nameof(GetSongById), 
                new { id = song.SongId },
                song);
        }

        [HttpPut("{id}")]
        [Song_ValidateSongIdFilter]
        [Song_ValidateUpdateShirtFilter]
        [Song_HandleUpdateExceptionsFilter]
        public IActionResult UpdateSong(int id, Song song)
        {
            SongRepo.UpdateSong(song);
            
            return NoContent();
        }

        [HttpDelete("{id}")]
        [Song_ValidateSongIdFilter]
        public IActionResult DeleteSong(int id)
        {
            var song = SongRepo.GetSongById(id);
            SongRepo.DeleteSong(id);

            return Ok(song);
        }
    }
}
