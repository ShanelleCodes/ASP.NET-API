﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using MusicAPI2.Models.Repositories;

namespace MusicAPI2.Filters.ExceptionFilters
{
    public class Song_HandleUpdateExceptionsFilterAttribute: ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            base.OnException(context);

            var strSongId = context.RouteData.Values["id"] as string;
            if (int.TryParse(strSongId, out var songId))
            {
                if (!SongRepo.SongExsists(songId))
                {
                    context.ModelState.AddModelError("SongId", "Song doesn't exist anymore.");
                    var problemDetails = new ValidationProblemDetails(context.ModelState)
                    {
                        Status = StatusCodes.Status404NotFound
                    };
                    context.Result = new NotFoundObjectResult(problemDetails);
                }
                    
            }
        }
    }
}
