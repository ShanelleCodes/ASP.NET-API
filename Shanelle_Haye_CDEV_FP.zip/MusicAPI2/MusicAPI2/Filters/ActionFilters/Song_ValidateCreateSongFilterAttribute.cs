﻿using Microsoft.AspNetCore.Mvc.Filters;
using MusicAPI2.Models.Repositories;
using MusicAPI2.Models;
using Microsoft.AspNetCore.Mvc;

namespace MusicAPI2.Filters.ActionFilters
{
    public class Song_ValidateCreateSongFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            var song = context.ActionArguments["song"] as Song;

            if (song == null)
            {
                context.ModelState.AddModelError("Song", "Song object is null.");
                var problemDetails = new ValidationProblemDetails(context.ModelState)
                {
                    Status = StatusCodes.Status400BadRequest
                };
                context.Result = new BadRequestObjectResult(problemDetails);
            }
            else
            {
                var existingSong = SongRepo.GetSongByProperties(song.SongName, song.Artist, song.Album, song.Year);
                if (existingSong != null)
                {
                    context.ModelState.AddModelError("Song", "Song already exists.");
                    var problemDetails = new ValidationProblemDetails(context.ModelState)
                    {
                        Status = StatusCodes.Status400BadRequest
                    };
                    context.Result = new BadRequestObjectResult(problemDetails);
                }
            }

        }
    }
}
