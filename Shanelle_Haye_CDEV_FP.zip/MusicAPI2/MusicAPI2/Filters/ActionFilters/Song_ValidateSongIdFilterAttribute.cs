﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using MusicAPI2.Models.Repositories;

namespace MusicAPI2.Filters.ActionFilters
{
    public class Song_ValidateSongIdFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            var songId = context.ActionArguments["id"] as int?;
            if (songId.HasValue)
            {
                if (songId.Value <= 0)
                {
                    context.ModelState.AddModelError("SongId", "SongId is invalid");
                    var problemDetails = new ValidationProblemDetails(context.ModelState)
                    {
                        Status = StatusCodes.Status400BadRequest
                    };
                    context.Result = new BadRequestObjectResult(problemDetails);
                }
                else if (!SongRepo.SongExsists(songId.Value))
                {
                    context.ModelState.AddModelError("SongId", "Song does not exist");
                    var problemDetails = new ValidationProblemDetails(context.ModelState)
                    {
                        Status = StatusCodes.Status404NotFound
                    };
                    context.Result = new NotFoundObjectResult(problemDetails);
                }
            }
        }
    }
}
