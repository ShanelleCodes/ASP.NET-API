﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using MusicAPI2.Models;

namespace MusicAPI2.Filters.ActionFilters
{
    public class Song_ValidateUpdateShirtFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);

            var id = context.ActionArguments["id"] as int?;
            var song = context.ActionArguments["song"] as Song;

            if (id.HasValue && song != null && id != song.SongId)
            {
                context.ModelState.AddModelError("SongId", "SongId is not the same id.");
                var problemDetails = new ValidationProblemDetails(context.ModelState)
                {
                    Status = StatusCodes.Status400BadRequest
                };
                context.Result = new BadRequestObjectResult(problemDetails);
            }

        }
    }
}
